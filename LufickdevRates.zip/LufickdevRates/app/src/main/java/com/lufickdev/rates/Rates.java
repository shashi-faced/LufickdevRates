package com.lufickdev.rates;

public class Rates {
    public String getBase() {
        return base;
    }

    public String getSuccess() {
        return success;
    }

    public String getDate() {
        return date;
    }

    public String[] getRates() {
        return rates;
    }

    private String base;
    private String success;
    private String date;
    private String rates[];

}
