package com.lufickdev.rates;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.Date;



public class MainActivity extends AppCompatActivity {

    Button btnRefresh;
    private ProgressDialog pDialog;
    ListView rateList;
    TextView lastUpdated;
    Button btnConvert;
    EditText inCurrency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rateList = (ListView)findViewById(R.id.rateList);
        btnRefresh = (Button) findViewById(R.id.refresh);
        lastUpdated = (TextView)findViewById(R.id.lastUpdated);
        btnConvert = (Button)findViewById(R.id.btnconvert);
        inCurrency = (EditText)findViewById(R.id.inCurrency);

        loadData();

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadData();
            }
        });

       btnConvert.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
              if( inCurrency.getText().toString().equals("")){
                  inCurrency.setError("Please provide currecny");
              }
              else {
                  Toast.makeText(getApplicationContext(), "Conversion feature coming soon...", Toast.LENGTH_LONG).show();
              }
           }
       });
    }

    private void loadData(){
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setMessage("Loading.. Please wait...");
        pDialog.show();
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        String url ="https://lufickdev.bitbucket.io/api/latest";
        JSONObject request = new JSONObject();
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.GET, url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.hide();
                        try {
                            String rates = response.getString("rates");
                            JSONObject rate = response.getJSONObject("rates");

                            JSONArray jsonArray = new JSONArray();;
                            jsonArray.put(rate);
                            String data = jsonArray.getString(0);
                            Log.i("merawala_data",data);
                            ArrayList<String> listdata = new ArrayList<String>();
                            String[] splitdata = data.split(",");
                            for (String s :  splitdata) {
                                listdata.add(s);
                            }
                            Date d = new Date();
                            CharSequence current_time  = DateFormat.format("HH:MM:ss, MMMM d, yyyy  ", d.getTime());
                            lastUpdated.setText(current_time);

                            ArrayAdapter<String> arrayAdapter =
                                    new ArrayAdapter<String>(
                                            MainActivity.this,
                                            R.layout.listview_design,
                                            listdata);
                            rateList.setAdapter(arrayAdapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
        queue.add(jsArrayRequest);
    }

}

